sed -i s/row-fluid/row/g $1
sed -i s/class=\"span/class=\"col\-md\-/g $1
sed -i s/container-narrow/container-fluid/g $1
